#!/usr/bin/env python3
"""
Step 3 — Count unique registrable domains (SLDs) per org
Input:  step3_enriched_*.txt  lines like: domain | ip | org
Output: org|domaincount CSV (thresholded)

Large sets are spilled to disk and deduplicated using external sort.

Example:
  python -m hosterbench.counts.unique_slds --config config/pipeline.yaml
"""

import os
import re
import csv
import logging
import tempfile
import subprocess
from glob import glob
from typing import Optional, List, Dict
from collections import defaultdict
from concurrent.futures import ProcessPoolExecutor, as_completed

from publicsuffix2 import get_sld

try:
    import yaml
except ImportError:
    yaml = None

# --------------------------------
# Logging
# --------------------------------
LOG_FORMAT = "%(asctime)s %(levelname)s: %(message)s"
logger = logging.getLogger("step3.slds")
logger.setLevel(logging.INFO)
_handler = logging.StreamHandler()
_handler.setFormatter(logging.Formatter(LOG_FORMAT))
logger.addHandler(_handler)


# --------------------------------
# Helpers
# --------------------------------
def to_sld(domain: str) -> Optional[str]:
    try:
        return get_sld(domain.strip().lower().rstrip("."))
    except Exception:
        return None


def flush_to_temp(org_slds: Dict[str, set], tmpdir: str) -> str:
    """Write current org→slds to a temp file."""
    tmp = tempfile.NamedTemporaryFile(delete=False, dir=tmpdir, prefix="flush_", suffix=".txt", mode="w")
    for org, slds in org_slds.items():
        for sld in slds:
            tmp.write(f"{org}|{sld}\n")
    tmp_path = tmp.name
    tmp.close()
    return tmp_path


def process_file(path: str, tmpdir: str, max_uniques: int = 5_000_000) -> List[str]:
    """Worker: process a single enriched file and return list of temp paths"""
    base = os.path.basename(path)
    logger.info(f"[{base}] processing")
    org_slds = defaultdict(set)
    total_uniques = 0
    tmp_paths = []

    with open(path, "rt", encoding="utf-8", errors="replace") as f:
        for line in f:
            if "|" not in line:
                continue
            parts = [p.strip() for p in line.split("|")]
            if len(parts) < 3:
                continue
            domain, ip, org = parts[0], parts[1], parts[2]
            sld = to_sld(domain)
            if org and sld:
                if sld not in org_slds[org]:
                    org_slds[org].add(sld)
                    total_uniques += 1

            if total_uniques >= max_uniques:
                tmp_paths.append(flush_to_temp(org_slds, tmpdir))
                org_slds.clear()
                total_uniques = 0

    if org_slds:
        tmp_paths.append(flush_to_temp(org_slds, tmpdir))

    return tmp_paths


def count_unique_slds_from_args(
    input_glob: str,
    tmpdir: str,
    threshold: int,
    output_file: str,
    max_uniques: int,
    processes: int = 1
) -> None:
    os.makedirs(tmpdir, exist_ok=True)
    files = sorted(glob(input_glob))
    if not files:
        logger.warning(f"No input files matched: {input_glob}")
        return

    logger.info(f"Step3: Counting SLDs from {len(files)} files with {processes} process(es)")

    all_tmpfiles = []
    with ProcessPoolExecutor(max_workers=processes) as ex:
        futs = [ex.submit(process_file, f, tmpdir, max_uniques) for f in files]
        for fu in as_completed(futs):
            all_tmpfiles.extend(fu.result())

    logger.info(f"Step3: Flushed to {len(all_tmpfiles)} temp files")

    merged = os.path.join(tmpdir, "all_pairs.txt")
    sorted_unique = os.path.join(tmpdir, "all_pairs_unique.txt")

    logger.info("Merging temp files...")
    with open(merged, "w") as out:
        for tf in all_tmpfiles:
            with open(tf) as f:
                for line in f:
                    out.write(line)
            os.remove(tf)

    logger.info("Deduplicating via external sort...")
    subprocess.run(["sort", "-u", "-T", tmpdir, "-S", "2G", merged, "-o", sorted_unique], check=True)
    os.remove(merged)

    logger.info("Counting per org...")
    counts = defaultdict(int)
    with open(sorted_unique) as f:
        for line in f:
            org, sld = line.strip().split("|", 1)
            counts[org] += 1
    os.remove(sorted_unique)

    with open(output_file, "w", newline="") as out:
        w = csv.writer(out, delimiter="|")
        w.writerow(["Organization", "domaincount"])
        for org, count in sorted(counts.items(), key=lambda x: -x[1]):
            if count > threshold:
                w.writerow([org, count])

    logger.info(f"Step3: Wrote {output_file}")


# --------------------------------
# YAML-driven variant
# --------------------------------
def _load_yaml_config(cfg_path: str) -> dict:
    if yaml is None:
        raise RuntimeError("PyYAML not installed. Use CLI flags or install pyyaml")
    with open(cfg_path, "r", encoding="utf-8") as fh:
        return yaml.safe_load(fh) or {}


def count_unique_slds(config_path: Optional[str] = None) -> None:
    if not config_path:
        raise ValueError("config_path required")

    cfg = _load_yaml_config(config_path)
    paths = cfg.get("paths", {})
    params = cfg.get("params", {})
    outputs = cfg.get("outputs", {})

    input_glob = paths.get("step1_out_dir", "") + "/step3_enriched_*.txt"
    tmpdir = params.get("tmpdir", "data/work/tmp")
    threshold = int(params.get("sld_threshold", 100))
    max_uniques = int(params.get("max_uniques", 5_000_000))
    processes = int(params.get("processes", 1))
    out_file = outputs.get("orgs_over_threshold", "data/output/orgs_over_100.csv")

    count_unique_slds_from_args(input_glob, tmpdir, threshold, out_file, max_uniques, processes)


def main():
    ap = argparse.ArgumentParser(description="Step 3: Count unique SLDs per org (with spill-to-disk)")
    ap.add_argument("--input-glob", help='Glob for enriched files (default: "step3_enriched_*.txt")')
    ap.add_argument("--tmpdir", default="data/work/tmp")
    ap.add_argument("--threshold", type=int, default=100)
    ap.add_argument("--max-uniques", type=int, default=5_000_000)
    ap.add_argument("--processes", type=int, default=1)
    ap.add_argument("--output", default="data/output/orgs_over_100.csv")
    ap.add_argument("--config", help="YAML config")
    args = ap.parse_args()

    if args.config:
        count_unique_slds(args.config)
        return

    if not args.input_glob:
        ap.error("--input-glob or --config is required")

    count_unique_slds_from_args(
        args.input_glob,
        args.tmpdir,
        args.threshold,
        args.output,
        args.max_uniques,
        args.processes
    )


if __name__ == "__main__":
    main()
